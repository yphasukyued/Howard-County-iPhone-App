#import <UIKit/UIKit.h>

void UIButton_Glossy_touch();

@interface UIButton (Glossy)

- (void) makeGlossy;

@end
